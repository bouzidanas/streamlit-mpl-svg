streamlit-mpl-svg  [![Version](https://img.shields.io/pypi/v/streamlit-mpl-svg)](https://pypi.org/project/streamlit-mpl-svg/#history) 
[![PyPi - Downloads](https://img.shields.io/pypi/dm/streamlit-mpl-svg)](https://pypi.org/project/streamlit-mpl-svg/#files)
============

Reformat Matplotlib SVGs for easier access and customzation with CSS

## Installation
Install [streamlit-mpl-svg](https://pypi.org/project/streamlit-mpl-svg/) with pip:
```bash
pip install streamlit-mpl-svg
```

## License
This project is licensed under the [MIT License](LICENSE.txt)